import org.openscience.cdk.DefaultChemObjectBuilder;
import org.openscience.cdk.exception.InvalidSmilesException;
import org.openscience.cdk.smiles.SmiFlavor;
import org.openscience.cdk.smiles.SmilesGenerator;
import org.openscience.cdk.smiles.SmilesParser;

import java.io.*;
import java.util.ArrayList;

public class CanonicalBatch {
    public static void main(String[] args) throws Exception {
        String dirPath = "F:/OneDrive - mail.ecust.edu.cn/毕业论文/基于规则方法对比实验/";
        String s = "30wan_molvec_PretectResult";
        String fileRead = dirPath + s + ".txt";
        String fileWrite = dirPath + s + "_Canioncal.txt";

//        canioncal_one();
        canioncal_batch(fileRead, fileWrite);
    }

    public static void canioncal_batch(String fileRead, String fileWrite) throws IOException, InvalidSmilesException {

        File record = new File(fileWrite);//记录结果文件
        FileWriter writer = new FileWriter(record, true);

        File file = new File(fileRead);
        BufferedReader reader = null;
        String temp = null;
        int line = 1;
        try {
            reader = new BufferedReader(new FileReader(file));
            while ((temp = reader.readLine()) != null) {
                /**
                 * SmiFlavor.Isomeric:会显示锲形键的 加粗的楔形表示处在纸面的外边面向你。无线表示在纸面背后。
                 * 重点：SmiFlavor.UseAromaticSymbols 芳香环SMILES唯一化必须带上此参数，因为CDK唯一化默认生成大写C，若没有该参数，则无论SMILES中C\c唯一化后均为C。
                 * 生成图片的代码设置.withAromaticDisplay()属性就可以了。
                 */
                try {
                    SmilesParser parser = new SmilesParser(DefaultChemObjectBuilder.getInstance());
                    SmilesGenerator generator = new SmilesGenerator(SmiFlavor.Canonical | SmiFlavor.Isomeric|SmiFlavor.UseAromaticSymbols);//小写c，芳香式唯一化
//                    SmilesGenerator generator = new SmilesGenerator(SmiFlavor.Canonical | SmiFlavor.Isomeric);//大写C,凯库勒唯一化

                    String[] sequence = temp.split("\t");
                    if (sequence.length == 1) {
                        if ("None".equals(sequence[0])) {
                            writer.write("None" + "\n");
                            continue;
                        }
                        String smilesCanonical = generator.create(parser.parseSmiles(sequence[0]));
                        writer.write(smilesCanonical + "\n");
                    } else {
                        String smilesCanonical = generator.create(parser.parseSmiles(sequence[1]));
                        writer.write(sequence[0] + "\t" + smilesCanonical + "\n");
                    }
                    line++;
                } catch (Exception e) {
//                    System.out.println("出错的SMILES" + line + "\t" + temp);
                    writer.write("None" + "\n");
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            writer.write("None" + "\n");
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void canioncal_one() throws IOException, InvalidSmilesException {

        SmilesParser parser = new SmilesParser(DefaultChemObjectBuilder.getInstance());

        /**SmiFlavor.Isomeric:会显示锲形键的
         * SmiFlavor.UseAromaticSymbols:会出现那种小的c,只有这个这只为true,生成的图片才会有苯圈，生成图片的代码设置.withAromaticDisplay()属性就可以了。
         */

        SmilesGenerator generator = new SmilesGenerator(SmiFlavor.UseAromaticSymbols | SmiFlavor.Isomeric | SmiFlavor.Canonical | SmiFlavor.CxSmiles);
//        SmilesGenerator generator = new SmilesGenerator(SmiFlavor.Isomeric | SmiFlavor.Canonical );

        String[] smi = {"C1=C(C=C(C(=C1)))C(=O)",
                "C1=C(C=C(C(=C1)[R20])Br)C(=O)[Rm]"};

        ArrayList<String> can = new ArrayList<String>();

        for (String s : smi) {
            can.add(generator.createSMILES(parser.parseSmiles(s)));
        }
        for (String s : can) {
            System.out.println(s);
        }

        if (can.get(0).equals(can.get(1))) {
            System.out.println("==");
        } else {
            System.out.println("!=");
        }
    }
}