import org.openscience.cdk.exception.CDKException;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 含有取代基的SMILES经过唯一化操作后，SMILES中原来的取代基会转换成"*"。该类用于将"*"还原为原来的取代基
 */
public class ReplaceSubstituentCanonicalAsterisk {
    public static void main(String[] args) throws IOException, CDKException {
        //这个是读的文件
        String fileRead = "G:\\360MoveData\\Users\\miracle\\Desktop\\old.txt";
        String fileWrite = "G:\\360MoveData\\Users\\miracle\\Desktop\\new.txt";
        ReplaceStarWithR(fileRead, fileWrite);
    }

    public static void ReplaceStarWithR(String fileRead, String fileWrite) throws CDKException, IOException {

        //记录结果文件
        File record = new File(fileWrite);
        FileWriter writer = new FileWriter(record, true);
        File file = new File(fileRead);
        BufferedReader reader = null;
        String temp = null;
        int line = 1;
        try {
            reader = new BufferedReader(new FileReader(file));
            while ((temp = reader.readLine()) != null) {
                String[] aa = temp.split("\t");
                temp = aa[1];
                boolean status = aa[1].contains("|");
                if (status) {
                    String[] str_ll = temp.split("\\|");

                    String new_0 = str_ll[0];

                    String new_1 = str_ll[1].replace("$", "");

                    List<String> replaceArray = new ArrayList<String>();

                    for (String s : new_1.split(";")) {
                        if (!s.equals("")) {
                            if (s.indexOf("&#44") != -1) {
                                int i = s.indexOf("&#44");
                                s = s.substring(0, i);// 找到单个卤素元素（F,CL等）
                            }
                            replaceArray.add(s);
                            ArrayList<String> alss_hou = new ArrayList<String>();
                            ArrayList<String> alss = new ArrayList<String>();
                            alss.add("F");
                            alss.add("Cl");
                            alss.add("Br");
                            alss.add("I");

                            if (replaceArray.containsAll(alss)) {
                                int in = replaceArray.indexOf(alss);
                                System.out.println("找到位置了" + in);
                            }
                            new_0 = new_0.replaceFirst("\\*", "[" + s + "]");
                        }

                        System.out.println(replaceArray);

                    }
                    ArrayList<String> a = new ArrayList<String>();
                    String c;
                    for (int i = 0; i < replaceArray.size(); i++) {
                        if (replaceArray.get(i) == "&#40") {
                            continue;
                        } else if (replaceArray.get(i).indexOf("&#41") != -1) {
                            c = '(' + replaceArray.get(i).substring(0, -4) + ')' + replaceArray.get(i + 1);
                            a.add(c);
                        } else if (replaceArray.get(i) == "F") {
                            c = "F,Cl,Br,I";
                            a.add(c);
                        } else {
                            if (a.get(a.size() - 1).indexOf(replaceArray.get(i)) != -1) {
                                a.add(replaceArray.get(i));
                            }
                        }
                        System.out.println(a);
                        writer.write(aa[0] + '\t' + new_0 + "\n");
                        writer.flush();
                    }

                } else {
                    writer.write(aa[0] + '\t' + aa[1] + "\n");
                    writer.flush();
                }

                line++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                reader.close();
            }
        }

    }
}
